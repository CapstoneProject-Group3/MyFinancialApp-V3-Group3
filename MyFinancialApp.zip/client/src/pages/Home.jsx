import React, { useEffect, useState } from 'react';

const Home = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [hasToken, setHasToken] = useState(false); // 新增状态，用于判断 token 是否存在

  useEffect(() => {
    const checkAuth = () => {
      // 获取存储在 localStorage 中的 JWT token
      const token = localStorage.getItem('token');

      if (token) {
        // 如果 token 存在，设置用户为已验证
        setIsAuthenticated(true);
        setHasToken(true);
      } else {
        // 如果没有 token，只显示未登录信息
        setHasToken(false);
      }
    };

    // 调用检查身份验证的函数
    checkAuth();
  }, []);

  // 处理用户点击 Logout
  const handleLogout = () => {
    // 删除 localStorage 中的 token
    localStorage.removeItem('token');
    // 更新状态
    setIsAuthenticated(false);
    setHasToken(false);
  };

  if (!hasToken) {
    return <div>You are not logged in.</div>; // 如果没有 token，显示未登录信息
  }

  return (
    <div>
      <h1>Welcome to the Home Page</h1>
      <p>You are authenticated and can view this content.</p>
      {/* 添加 Logout 按钮 */}
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Home;
